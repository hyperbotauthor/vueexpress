. env.sh
nodemon --exec 'vue-cli-service serve'
