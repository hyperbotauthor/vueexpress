Store temporary server generated files.
