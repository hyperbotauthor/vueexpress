# vueexpress

Vue UI with Express API.

## Features

### [Oauth](https://appvueexpress.herokuapp.com/)

Lichess login with client side oauth.

### [Board drawing API](https://appvueexpress.herokuapp.com/api/board?fen=&moves=&arrows=&circles=&size=&player=&variant=&flip=)

Create a board scrrenshot using an API.[

See https://lichess.org/@/hyperchessbotauthor/blog/board-image-api/j9TaGcbL .
