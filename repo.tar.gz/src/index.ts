import { api } from "./api";

export { api };

import AppComponent from "./components/HelloWorld.vue";

export { AppComponent };
