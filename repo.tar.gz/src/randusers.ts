import { createApp } from "vue";
import Randusers from "./Randusers.vue";

createApp(Randusers).mount("#app");
