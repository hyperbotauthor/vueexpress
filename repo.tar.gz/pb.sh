. env.sh

. p.sh $*

. hb.sh