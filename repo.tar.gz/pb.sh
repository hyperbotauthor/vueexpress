. env.sh

. p.sh $*

. h.sh setconfig
. h.sh build