node login.js
cat exports.sh
. exports.sh
rm exports.sh