. h.sh setconfig
. h.sh build