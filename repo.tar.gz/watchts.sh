nodemon --watch src --ext ts,js --exec yarn prettiersrc &
nodemon --watch src --ext ts,js --delay 5 --exec yarn testbuild
