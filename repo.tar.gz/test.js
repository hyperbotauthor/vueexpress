const items = [
/*    {
        createdAt: 150
    },
    {
        createdAt: 100
    },
    {
        createdAt: 120
    },*/
]

/*console.log(items)

console.log(items.reduce((acc, curr)=>{
    const newAcc = curr.createdAt < acc.createdAt ? curr : acc
    console.log(acc, curr, newAcc)
    return newAcc
}, undefined))*/

console.log(JSON.parse(""))